package monster;

import java.util.Observer;

import monster.beobachter.SchreckwertBeobachter;
import monster.monster.Hexenmaske;
import monster.monster.Kobold;
import monster.monster.Kruemelmonster;
import monster.monster.Monster;

public class MonsterTestDrive {

	public static void main(String[] args) {
		Observer beobachter;
		beobachter = new SchreckwertBeobachter();

		Monster monster1 = new Kruemelmonster();
		monster1.darstellen();
		monster1.addObserver(beobachter);
		monster1.kommunizieren();
		System.out.println();
		
		Monster monster2 = new Kobold();
		monster2.darstellen();
		monster2.addObserver(beobachter);
		monster2.kommunizieren();
		monster2.addGegenstand(new Hexenmaske());
		monster2.darstellen();
		monster2.kommunizieren();
		System.out.println();
		
		
	}
}
