package monster.geister;

public interface Geist {
	public void anzeigen();
	
}
