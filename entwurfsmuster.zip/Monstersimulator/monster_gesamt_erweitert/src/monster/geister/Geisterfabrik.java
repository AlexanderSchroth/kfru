package monster.geister;


public class Geisterfabrik {

	public static Geist createGeist(GeistTyp typ) {
		Geist geist = null;
		
		if (typ == GeistTyp.POLTERGEIST) {
			geist = new Poltergeist();
		}
		else if (typ == GeistTyp.SUMPFGEIST) {
			geist = new Sumpfgeist();
		}
		
		return geist;
	}
}
