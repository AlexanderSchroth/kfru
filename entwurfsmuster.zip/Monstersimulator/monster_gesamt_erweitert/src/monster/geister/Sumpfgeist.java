package monster.geister;

public class Sumpfgeist implements Geist {

	
	public void anzeigen() {
		System.out.println("Tssssss. Der Sumpfgeist wird Dich holen.");
	}

}
