package monster.geister;

public class Poltergeist implements Geist {

	
	public void anzeigen() {
		System.out.println("Huhuuu. Ich bin ein Poltergeist");
	}

}
