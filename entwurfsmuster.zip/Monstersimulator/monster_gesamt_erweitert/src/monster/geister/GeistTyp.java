package monster.geister;

public enum GeistTyp {
	POLTERGEIST,
	SUMPFGEIST
}
