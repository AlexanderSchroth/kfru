package monster.geister;

import monster.monster.Monster;

public class GeistAdapter extends Monster {
	Geist geist;
	
	public GeistAdapter(Geist geist) {
		super();
		this.geist = geist;
		// Alle Geister haben denselben Schreckwert
		schreckwert = 2;  
		ermittleVerhalten();
	}
	
	public int berechne() {
		return schreckwert;
	}

	public void darstellenMonster() {
		geist.anzeigen();		
	}

}
