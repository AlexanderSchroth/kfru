package monster.beobachter;

import java.util.Observable;
import java.util.Observer;

import monster.monster.Monster;

public class SchreckwertBeobachter implements Observer {

	@Override
	public void update(Observable observable, Object data) {
		if (observable instanceof Monster) {
			System.out.println("Beobachter: " + ((Monster)observable).berechneSchreckwert());
		}
		if (data instanceof Integer) {
			System.out.println("Beobachter meldet: Schreckwert ge�ndert: " + (Integer)data);
		}
	}

}
