package monster.gebaeude;

public interface Gebaeude {
	
	public void darstellen();

}
