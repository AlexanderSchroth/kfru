package monster.gebaeude;

public class Hoehle implements Gebaeude {
	
	public void darstellen() {
		System.out.println("Eine H�hle");
	}
	
}
