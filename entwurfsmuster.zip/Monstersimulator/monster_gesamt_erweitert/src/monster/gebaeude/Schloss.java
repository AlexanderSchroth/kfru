package monster.gebaeude;

public class Schloss implements Gebaeude {

	public void darstellen() {
		System.out.println("Ein Schloss");
	};
	
}
