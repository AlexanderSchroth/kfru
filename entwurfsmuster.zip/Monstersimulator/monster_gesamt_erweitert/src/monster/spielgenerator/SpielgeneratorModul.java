package monster.spielgenerator;

import com.google.inject.AbstractModule;

public class SpielgeneratorModul extends AbstractModule {

	@Override
	protected void configure() {
		bind(Spielgenerator.class)
				.to(GeisterSpielGenerator.class);
				//.to(MonsterSpielGenerator.class);
	}
}
