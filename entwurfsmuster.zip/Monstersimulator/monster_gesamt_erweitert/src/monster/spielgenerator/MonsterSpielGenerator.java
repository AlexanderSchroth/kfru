package monster.spielgenerator;

import monster.gebaeude.Gebaeude;
import monster.gebaeude.Hoehle;
import monster.gelaende.Gebirge;
import monster.gelaende.Gelaende;
import monster.monster.Monster;
import monster.monster.Monsterfabrik;

public class MonsterSpielGenerator implements Spielgenerator {

	@Override
	public Monster createKreatur() {
		return new Monsterfabrik().createMonster("Kobold");
	}

	@Override
	public Gebaeude createGebaeude() {
		return new Hoehle();
	}

	@Override
	public Gelaende createGelaende() {
		return new Gebirge();
	}

}
