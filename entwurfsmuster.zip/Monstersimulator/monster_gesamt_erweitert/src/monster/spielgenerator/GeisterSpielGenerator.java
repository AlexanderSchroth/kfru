package monster.spielgenerator;

import monster.gebaeude.Gebaeude;
import monster.gebaeude.Schloss;
import monster.geister.GeistAdapter;
import monster.geister.GeistTyp;
import monster.geister.Geisterfabrik;
import monster.gelaende.Gelaende;
import monster.gelaende.Sumpfgebiet;
import monster.monster.Monster;

public class GeisterSpielGenerator implements Spielgenerator {

	@Override
	public Monster createKreatur() {
		return new GeistAdapter(Geisterfabrik.createGeist(GeistTyp.POLTERGEIST));
	}

	@Override
	public Gebaeude createGebaeude() {
		return new Schloss();
	}

	@Override
	public Gelaende createGelaende() {
		return new Sumpfgebiet();
	}
	
	

}
