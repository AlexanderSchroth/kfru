package monster.spielgenerator;

import com.google.inject.Inject;

public class SpielgeneratorProvider {
	private Spielgenerator spielgenerator;
	
	@Inject
	public SpielgeneratorProvider(Spielgenerator spielgenerator) {
		this.spielgenerator = spielgenerator;
	}
	
	public Spielgenerator getSpielgenerator() {
		return spielgenerator;
	}
}
