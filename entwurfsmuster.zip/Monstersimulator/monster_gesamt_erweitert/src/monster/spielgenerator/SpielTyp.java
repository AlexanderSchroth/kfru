package monster.spielgenerator;

public enum SpielTyp {
	GEISTERWELT,
	MONSTERWELT
}
