package monster.spielgenerator;

import monster.gebaeude.Gebaeude;
import monster.gelaende.Gelaende;
import monster.monster.Monster;

public interface Spielgenerator {
	
	public Monster createKreatur();
	public Gebaeude createGebaeude();
	public Gelaende createGelaende();

}
