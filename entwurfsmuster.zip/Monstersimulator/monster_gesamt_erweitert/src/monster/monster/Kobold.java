package monster.monster;


public class Kobold extends Monster {

	public Kobold() {
		super();
		schreckwert = 0;
		ermittleVerhalten();
	}
	
	public void darstellenMonster() {
		System.out.println("Ich bin ein Kobold mit Schreckwert: " + berechneSchreckwert());
	}
	
	public boolean canHandle(String typ) {
		return typ.equalsIgnoreCase("Kobold");
	}

}
