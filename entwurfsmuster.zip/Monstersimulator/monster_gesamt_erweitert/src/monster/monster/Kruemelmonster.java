package monster.monster;


public class Kruemelmonster extends Monster {

	public Kruemelmonster() {
		super();
		schreckwert = -5;
		ermittleVerhalten();
	}
	
	public void darstellenMonster() {
		System.out.println("Ich bin ein Kruemelmonster mit Schreckwert: " + berechneSchreckwert());
	}
	
	public boolean canHandle(String typ) {
		return typ.equalsIgnoreCase("Kruemelmonster");
	}
}
