package monster.monster;


public class Monsterfabrik {

	public Monster createMonster(String typ) {
		Monster monster = null;

		if (typ.equals("Kobold")) {
			monster = new Kobold();
		}
		else if (typ.equals("Drache")) {
			monster = new Drache();
		}
		else if (typ.equals("Kr�melmonster")) {
			monster = new Kruemelmonster();
		}
		
		return monster;
	}
}
