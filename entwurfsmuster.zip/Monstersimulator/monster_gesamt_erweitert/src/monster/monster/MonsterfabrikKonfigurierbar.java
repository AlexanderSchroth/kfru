package monster.monster;

import java.util.Properties;

public class MonsterfabrikKonfigurierbar {

	public Monster createMonster(String typ) {
		Monster monster = null;

		Properties properties = new Properties();
		try {
			properties.load(this.getClass().getResourceAsStream("monsterfactory.properties"));
			String monsterName = properties.getProperty(typ);
			Class<?> classOfProtocolHandler = Class.forName(monsterName);
			monster = (Monster) classOfProtocolHandler.newInstance();
			return monster;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return monster;
	}
}
