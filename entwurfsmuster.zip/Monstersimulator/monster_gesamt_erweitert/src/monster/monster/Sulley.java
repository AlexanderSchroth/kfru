package monster.monster;


public class Sulley extends MonsterRegistriert {

	static {
		MonsterRegistry.register(new Sulley());
	}

	public Sulley() {
		super();
		schreckwert = 5;
		ermittleVerhalten();
	}
	
	public void darstellenMonster() {
		System.out.println("Ich bin Sulley mit Schreckwert: " + berechneSchreckwert());
	}
	
	public boolean canHandle(String typ) {
		return typ.equalsIgnoreCase("Sulley");
	}

}
