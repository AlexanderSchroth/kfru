package monster.monster;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;

import monster.verhalten.Verhalten;
import monster.verhalten.Verhaltensfabrik;
import monster.zustaende.Arbeiten;
import monster.zustaende.Ausruhen;
import monster.zustaende.Essen;
import monster.zustaende.Heilend;
import monster.zustaende.Kaempfend;
import monster.zustaende.Schlafen;
import monster.zustaende.Zustand;

public abstract class Monster extends Observable {
	protected int schreckwert;
	protected ArrayList<Gegenstand> gegenstaende;
	protected Verhalten verhalten;
	private Zustand zustand;
	private Zustand schlafen;
	private Zustand essen;
	private Zustand ausruhen;
	private Zustand arbeiten;
	private Zustand heilend;
	private Zustand kaempfend;
	
	public Monster() {
		gegenstaende = new ArrayList<Gegenstand>();
		schlafen = new Schlafen(this);
		essen = new Essen(this);
		ausruhen = new Ausruhen(this);
		arbeiten = new Arbeiten(this);
		heilend = new Heilend(this);
		kaempfend = new Kaempfend(this);
		zustand = schlafen;
	}
	
	public abstract void darstellenMonster();
	
	public void addGegenstand(Gegenstand g) {
		gegenstaende.add(g);
		setChanged();
		notifyObservers(berechneSchreckwert());
		ermittleVerhalten();
	}
	
	public Iterator<Gegenstand> getGegenstaende() {
		return gegenstaende.iterator();
	}
	
	public int berechneSchreckwert() {
		int sum;
		
		sum = schreckwert;
		Iterator<Gegenstand> i = getGegenstaende();
		while (i.hasNext()) {
			sum = sum + ((Gegenstand)i.next()).schreckwert;
		}
		
		return sum;
	}
	
	public void darstellen() {
		darstellenMonster();
		Iterator<Gegenstand> i = getGegenstaende();
		while (i.hasNext()) {
			System.out.println("Ich besitze: " + ((Gegenstand)i.next()).beschreibung);
		}
	}
	
	public void ermittleVerhalten() {
		verhalten = Verhaltensfabrik.ermittleVerhalten(berechneSchreckwert());
	}

	public void kommunizieren() {
		verhalten.kommunizieren();
	}
	
	public Zustand getSchlafen() {
		return schlafen;
	}
	
	public Zustand getEssen() {
		return essen;
	}
	
	public Zustand getAusruhen() {
		return ausruhen;
	}

	public Zustand getArbeiten() {
		return arbeiten;
	}

	public Zustand getHeilend() {
		return heilend;
	}

	public Zustand getKaempfend() {
		return kaempfend;
	}

	public void setZustand(Zustand zustand) {
		this.zustand = zustand;
	}

	public Zustand getZustand() {
		return zustand;
	}

	// Ereignisse
	public void schlafenEreignis() {
		zustand.schlafenEreignis();
	}
	
	public void aufstehenEreignis() {
		zustand.aufstehenEreignis();
	}
	
	public void ausruhenEreignis() {
		zustand.ausruhenEreignis();
	}
	
	public void arbeitenEreignis() {
		zustand.arbeitenEreignis();
	}
	
	public void essenEreignis() {
		zustand.essenEreignis();
	}
	
	public void hexeKommtEreignis() {
		zustand.hexeKommtEreignis();
	}
	
	public void hexeGehtEreignis() {
		zustand.hexeGehtEreignis();
	}
	
	public void geheiltEreignis() {
		zustand.geheiltEreignis();
	}
	
	public void verletztEreignis() {
		zustand.verletztEreignis();
	}
	
	// Aktionen
	public void einschlafenAktion() {
		System.out.println("Einschlafen");
	}
	
	public void aufwachenAktion() {
		System.out.println("Aufwachen");
	}
	
	public void schlafenAktion() {
		System.out.println("Schlafen");
	}
	
	public void aufstehenAktion() {
		System.out.println("Aufstehen");
	}
	
	public void essenAktion() {
		System.out.println("Essen");
	}
	
	public void ausruhenAktion() {
		System.out.println("Ausruhen");
	}
	
	public void arbeitenAktion() {
		System.out.println("Arbeiten");
	}
	
	public void kaempfenAktion() {
		System.out.println("K�mpfen");
	}
	
	public void heilenAktion() {
		System.out.println("Heilen");
	}
	
}
