package monster.monster;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class MonsterRegistry {


		static List<MonsterRegistriert> monsters = new ArrayList<MonsterRegistriert>();
		
		static void register(MonsterRegistriert monster) {
			monsters.add(monster);
		}
		
		public static MonsterRegistriert getMonster(String typ) {
			ListIterator<MonsterRegistriert> iter = monsters.listIterator();
			while (iter.hasNext()) {
				MonsterRegistriert monster = iter.next();
				if (monster.canHandle(typ)) {
					return monster;
				}
			}
			return null;
		}
		

}
