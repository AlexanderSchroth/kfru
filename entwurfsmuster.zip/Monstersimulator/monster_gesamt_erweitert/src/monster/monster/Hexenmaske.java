package monster.monster;

public class Hexenmaske extends Gegenstand {

	public Hexenmaske() {
		super();
		schreckwert = 2;
		beschreibung = "Hexenmaske";
	}
}
