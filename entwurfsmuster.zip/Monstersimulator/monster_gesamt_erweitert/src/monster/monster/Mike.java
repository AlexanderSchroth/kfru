package monster.monster;


public class Mike extends MonsterRegistriert {

	static {
		MonsterRegistry.register(new Mike());
	}

	public Mike() {
		super();
		schreckwert = -5;
		ermittleVerhalten();
	}
	
	public void darstellenMonster() {
		System.out.println("Ich bin Mike mit Schreckwert: " + berechneSchreckwert());
	}
	
	public boolean canHandle(String typ) {
		return typ.equalsIgnoreCase("Mike");
	}

}
