package monster.monster;

public abstract class MonsterRegistriert extends Monster {

	public abstract boolean canHandle(String typ);

}
