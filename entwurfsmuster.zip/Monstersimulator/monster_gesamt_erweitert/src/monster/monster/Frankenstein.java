package monster.monster;

public class Frankenstein extends Gegenstand {

	public Frankenstein() {
		super();
		schreckwert = 1;
		beschreibung = "Frankensteinschraube";
	}
}
