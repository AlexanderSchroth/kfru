package monster.monster;

public class Clownsnase extends Gegenstand {

	public Clownsnase() {
		super();
		schreckwert = -3;
		beschreibung = "Clownsnase";
	}

}
