package monster.monster;


public class Drache extends Monster {

	public Drache() {
		super();
		schreckwert = 5;
		ermittleVerhalten();
	}
	
	public void darstellenMonster() {
		System.out.println("Ich bin ein Drache mit Schreckwert: " + berechneSchreckwert());
	}
	
	public boolean canHandle(String typ) {
		return typ.equalsIgnoreCase("Drache");
	}

}
