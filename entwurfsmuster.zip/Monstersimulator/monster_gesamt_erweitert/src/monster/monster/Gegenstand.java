package monster.monster;

public abstract class Gegenstand {
	protected int schreckwert;
	protected String beschreibung;
	
}
