package monster.monster;

import monster.geister.GeistAdapter;
import monster.geister.Poltergeist;
import monster.geister.Sumpfgeist;

public class LustigeMonsterfabrik extends Monsterfabrik {

	public Monster createMonster(String typ) {
		Monster monster;
		
		switch (typ) {
		case "Poltergeist":		
			monster = new GeistAdapter(new Poltergeist());
			break;
		case "Sumpfgeist":
			monster = new GeistAdapter(new Sumpfgeist());
			break;
		default:
			monster = super.createMonster(typ);
		}
		if (monster != null) {
			monster.addGegenstand(new Clownsnase());
		}
		return monster;
	}
}
