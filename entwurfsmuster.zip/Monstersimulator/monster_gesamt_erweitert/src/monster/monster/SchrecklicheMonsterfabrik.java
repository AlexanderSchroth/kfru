package monster.monster;

public class SchrecklicheMonsterfabrik extends Monsterfabrik {

	public Monster createMonster(String typ) {
		Monster monster = super.createMonster(typ);
		if (monster != null) {
			monster.addGegenstand(new Frankenstein());
		}
		return monster;
	}
}
