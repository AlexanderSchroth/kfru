package monster.zustaende;

import monster.monster.Monster;

public class Heilend extends Kampfmodus {

	public Heilend(Monster m) {
		super(m);
	}

	public void geheiltEreignis() {
		exit();
		m.setZustand(m.getKaempfend());
		m.kaempfenAktion();
		m.getZustand().entry();
	}

}
