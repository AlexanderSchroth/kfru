package monster.zustaende;

import monster.monster.Monster;

public class Kaempfend extends Kampfmodus {

	public Kaempfend(Monster m) {
		super(m);
	}

	public void verletztEreignis() {
		exit();
		m.setZustand(m.getHeilend());
		m.heilenAktion();
		m.getZustand().entry();
	}
}
