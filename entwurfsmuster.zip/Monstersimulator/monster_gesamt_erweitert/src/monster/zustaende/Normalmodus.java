package monster.zustaende;

import monster.monster.Monster;

public abstract class Normalmodus extends Zustand {

	public Normalmodus(Monster m) {
		super(m);
	}

	public void hexeKommtEreignis() {
		exit();
		m.setZustand(m.getKaempfend());
		m.kaempfenAktion();
		m.getZustand().entry();
	}
}
