package monster.zustaende;

import monster.monster.Monster;

public class Schlafen extends Normalmodus {

	public Schlafen(Monster m) {
		super(m);
	}

	public void exit() {
		m.aufwachenAktion();
	}
	
	public void entry() {
		m.einschlafenAktion();
	}
	
	public void aufstehenEreignis() {
		exit();
		m.setZustand(m.getEssen());
		m.aufstehenAktion();
		//System.out.println("Zustand Essen");
		m.getZustand().entry();
	}
}
