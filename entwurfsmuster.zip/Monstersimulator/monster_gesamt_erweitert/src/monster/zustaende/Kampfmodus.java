package monster.zustaende;

import monster.monster.Monster;

public abstract class Kampfmodus extends Zustand {

	public Kampfmodus(Monster m) {
		super(m);
	}

	public void hexeGehtEreignis() {
		exit();
		m.setZustand(m.getSchlafen());
		m.schlafenAktion();
		m.getZustand().entry();
	}

}
