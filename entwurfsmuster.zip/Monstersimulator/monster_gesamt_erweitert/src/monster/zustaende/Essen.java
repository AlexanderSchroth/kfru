package monster.zustaende;

import monster.monster.Monster;

public class Essen extends Normalmodus {

	public Essen(Monster m) {
		super(m);
	}

	public void schlafenEreignis() {
		m.setZustand(m.getSchlafen());
		m.schlafenAktion();
		System.out.println("Zustand Schlafen");
		m.getZustand().entry();
	}

	public void ausruhenEreignis() {
		exit();
		m.setZustand(m.getAusruhen());
		m.ausruhenAktion();
		System.out.println("Zustand Essen");
		m.getZustand().entry();
	}

	public void arbeitenEreignis() {
		exit();
		m.setZustand(m.getArbeiten());
		m.arbeitenAktion();
		m.getZustand().entry();
	}
}
