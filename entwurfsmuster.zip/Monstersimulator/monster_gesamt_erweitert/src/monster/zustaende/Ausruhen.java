package monster.zustaende;

import monster.monster.Monster;

public class Ausruhen extends Normalmodus {

	public Ausruhen(Monster m) {
		super(m);
	}

	public void schlafenEreignis() {
		exit();
		m.setZustand(m.getSchlafen());
		m.schlafenAktion();
		m.getZustand().entry();
	}

	public void arbeitenEreignis() {
		exit();
		m.setZustand(m.getArbeiten());
		m.arbeitenAktion();
		m.getZustand().entry();
	}

	public void essenEreignis() {
		exit();
		m.setZustand(m.getEssen());
		m.essenAktion();
		m.getZustand().entry();
	}

}
