package monster.zustaende;

import monster.monster.Monster;


public abstract class Zustand {
	protected Monster m;

	public Zustand(Monster m) {
		this.m = m;
	}
	
	public void aufstehenEreignis() {};
	public void schlafenEreignis() {};
	public void arbeitenEreignis() {};
	public void ausruhenEreignis() {};
	public void essenEreignis() {};
	public void hexeKommtEreignis() {};
	public void hexeGehtEreignis() {};
	public void geheiltEreignis() {};
	public void verletztEreignis() {};
	public void entry() {};
	public void exit() {};
}
