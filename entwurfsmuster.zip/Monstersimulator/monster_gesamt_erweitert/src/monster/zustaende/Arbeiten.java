package monster.zustaende;

import monster.monster.Monster;

public class Arbeiten extends Normalmodus {

	public Arbeiten(Monster m) {
		super(m);
	}

	public void ausruhenEreignis() {
		exit();
		m.setZustand(m.getAusruhen());
		m.ausruhenAktion();
		m.getZustand().entry();
	}
	
	public void essenEreignis() {
		exit();
		m.setZustand(m.getEssen());
		m.essenAktion();
		m.getZustand().entry();
	}

}
