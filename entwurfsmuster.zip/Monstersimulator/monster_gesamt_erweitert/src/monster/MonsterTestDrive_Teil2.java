package monster;

import java.util.Observer;

import monster.beobachter.SchreckwertBeobachter;
import monster.geister.Geist;
import monster.geister.GeistAdapter;
import monster.geister.Poltergeist;
import monster.geister.Sumpfgeist;
import monster.monster.Clownsnase;
import monster.monster.Drache;
import monster.monster.Hexenmaske;
import monster.monster.Kobold;
import monster.monster.Kruemelmonster;
import monster.monster.Monster;

public class MonsterTestDrive_Teil2 {

	public static void main(String[] args) {
		Observer beobachter;
		beobachter = new SchreckwertBeobachter();

		Monster monster1 = new Kruemelmonster();
		monster1.darstellen();
		monster1.addObserver(beobachter);
		monster1.kommunizieren();
		System.out.println();
		
		Monster monster2 = new Kobold();
		monster2.darstellen();
		monster2.addObserver(beobachter);
		monster2.kommunizieren();
		monster2.addGegenstand(new Hexenmaske());
		monster2.darstellen();
		monster2.kommunizieren();
		System.out.println();
		
		Monster monster3 = new Drache();
		monster3.darstellen();
		monster3.addObserver(beobachter);
		monster3.kommunizieren();
		monster3.aufstehenEreignis(); // schlafen -> essen
		monster3.arbeitenEreignis();  // essen -> arbeiten
		monster3.ausruhenEreignis();  // arbeiten -> ausruhen
		monster3.schlafenEreignis();  // ausruhen -> schlafen
		System.out.println();
		
		Geist geist1 = new Poltergeist();
		geist1.anzeigen();
		System.out.println();
		
		Monster geist2 = new GeistAdapter(new Sumpfgeist());
		geist2.darstellen();
		geist2.addObserver(beobachter);
		geist2.kommunizieren();
		geist2.addGegenstand(new Clownsnase());
		geist2.darstellen();
		geist2.kommunizieren();
		System.out.println();
		
//		Monsterfabrik fabrik = new SchrecklicheMonsterfabrik();
//		Monster monster4 = fabrik.createMonster("Smaug");
//		monster4.darstellen();
//		monster4.kommunizieren();
//		System.out.println();
//
//		Monsterfabrik monsterFabrik = new Monsterfabrik();
//		Monster monster5 = monsterFabrik.createMonster("Kobold");
//		monster5.darstellen();
//		monster5.kommunizieren();
//		monster5.aufstehenEreignis();
//		monster5.hexeKommt();
//		monster5.verletzt();
//		monster5.geheilt();
//		monster5.hexeGeht();
//		System.out.println();
//		 
//		Monster monster6 = new GeistAdapter(Geisterfabrik.createGeist(GeistTyp.SUMPFGEIST));
//		monster6.darstellen();
//		monster6.kommunizieren();
//		System.out.println();
//
//		Spielgenerator generator = new MonsterSpielGenerator();
//		Monster monster7 = generator.createKreatur();
//		Gebaeude gebaeude7 = generator.createGebaeude();
//		Gelaende gelaende7 = generator.createGelaende();
//		monster7.darstellen();
//		gebaeude7.darstellen();
//		gelaende7.darstellen();
//		System.out.println();
//		
//		generator = new GeisterSpielGenerator();
//		Monster monster8 = generator.createKreatur();
//		Gebaeude gebaeude8 = generator.createGebaeude();
//		Gelaende gelaende8 = generator.createGelaende();
//		monster8.darstellen();
//		gebaeude8.darstellen();
//		gelaende8.darstellen();
//		System.out.println();

	}
}
