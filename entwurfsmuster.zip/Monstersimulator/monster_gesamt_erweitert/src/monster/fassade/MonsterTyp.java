package monster.fassade;

public enum MonsterTyp {
	KOBOLD,
	DRACHE,
	KRUEMELMONSTER,
	POLTERGEIST,
	SUMPFGEIST,
	LUSTIGER_POLTERGEIST,
	SMAUG	
}
