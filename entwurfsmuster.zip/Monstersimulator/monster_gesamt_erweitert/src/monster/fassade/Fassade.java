package monster.fassade;

import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

import monster.beobachter.SchreckwertBeobachter;
import monster.gebaeude.Gebaeude;
import monster.geister.GeistAdapter;
import monster.geister.GeistTyp;
import monster.geister.Geisterfabrik;
import monster.gelaende.Gelaende;
import monster.monster.LustigeMonsterfabrik;
import monster.monster.Monster;
import monster.monster.Monsterfabrik;
import monster.monster.SchrecklicheMonsterfabrik;
import monster.spielgenerator.GeisterSpielGenerator;
import monster.spielgenerator.MonsterSpielGenerator;
import monster.spielgenerator.SpielTyp;
import monster.spielgenerator.Spielgenerator;

public class Fassade {
	Observer beobachter = new SchreckwertBeobachter();
	List<Monster> monsterliste = new ArrayList<Monster>();
	List<Gebaeude> gebaeudeliste = new ArrayList<Gebaeude>();
	List<Gelaende> gelaendeliste = new ArrayList<Gelaende>();
	Spielgenerator generator;
	
	public void initGame(SpielTyp typ) {
		switch(typ) {
			case GEISTERWELT:
				generator = new GeisterSpielGenerator();
				monsterliste.add(generator.createKreatur());
				gebaeudeliste.add(generator.createGebaeude());
				gelaendeliste.add(generator.createGelaende());
				break;
			case MONSTERWELT:
				generator = new MonsterSpielGenerator();
				monsterliste.add(generator.createKreatur());
				gebaeudeliste.add(generator.createGebaeude());
				gelaendeliste.add(generator.createGelaende());
				break;
			default:
				break;
		}
	}
		
	public void spielzugDurchfuehren() {
		for (Monster m : monsterliste) {
			m.darstellen();
		}
	}

	public void hexeKommtEreignis() {
		for (Monster m : monsterliste) {
			m.hexeKommtEreignis();
		}
	}
	
	public void hexeGehtEreignis() {
		for (Monster m : monsterliste) {
			m.hexeGehtEreignis();
		}
	}
	
	public void erstelleMonster(MonsterTyp typ) {
		Monster m = null;
		
		switch (typ) {
		case KOBOLD:
			m = new Monsterfabrik().createMonster("Kobold");
			break;
		case DRACHE:
			m = new Monsterfabrik().createMonster("Drache");
			break;
		case KRUEMELMONSTER:
			m = new Monsterfabrik().createMonster("Kruemelmonster");
			break;
		case POLTERGEIST:
			m = new GeistAdapter(Geisterfabrik.createGeist(GeistTyp.POLTERGEIST));
			break;
		case SUMPFGEIST:
			m = new GeistAdapter(Geisterfabrik.createGeist(GeistTyp.SUMPFGEIST));
			break;
		case LUSTIGER_POLTERGEIST:
			m = new LustigeMonsterfabrik().createMonster("Lustiger Poltergeist");
			break;
		case SMAUG:
			m = new SchrecklicheMonsterfabrik().createMonster("Smaug");
			break;
		default:
			break;
		}

		if (m != null) {
			monsterliste.add(m);
		}

	}

}