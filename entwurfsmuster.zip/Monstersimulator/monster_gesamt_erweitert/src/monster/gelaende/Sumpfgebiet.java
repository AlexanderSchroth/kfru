package monster.gelaende;

public class Sumpfgebiet implements Gelaende {

	public void darstellen() {
		System.out.println("Ein Sumpfgebiet");
	}
}
