package monster.gelaende;

public class Gebirge implements Gelaende {

	public void darstellen() {
		System.out.println("Gebirgslandschaft");
	}
}
