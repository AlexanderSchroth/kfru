package monster.gelaende;

public interface Gelaende {
	
	public void darstellen();
}
