package monster;

import java.util.Observer;

import com.google.inject.Guice;
import com.google.inject.Injector;

import monster.beobachter.SchreckwertBeobachter;
import monster.gebaeude.Gebaeude;
import monster.gelaende.Gelaende;
import monster.monster.Monster;
import monster.monster.MonsterRegistriert;
import monster.monster.MonsterRegistry;
import monster.monster.MonsterfabrikKonfigurierbar;
import monster.spielgenerator.Spielgenerator;
import monster.spielgenerator.SpielgeneratorModul;
import monster.spielgenerator.SpielgeneratorProvider;

public class MonsterTestDrive_Teil4 {

	public static void main(String[] args) {
		Observer beobachter;
		beobachter = new SchreckwertBeobachter();

		System.out.println("Konfigurierbare Fabrik");
		MonsterfabrikKonfigurierbar konfFabrik = new MonsterfabrikKonfigurierbar();
		Monster monster1 = konfFabrik.createMonster("Drache");
		monster1.darstellen();
		monster1.addObserver(beobachter);
		monster1.kommunizieren();
		System.out.println();
		
		System.out.println("Registratur");
		try {
			Class.forName("monster.monster.Sulley");
			Class.forName("monster.monster.Mike");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		MonsterRegistriert sulley = MonsterRegistry.getMonster("Sulley");
		if (sulley != null) {
			sulley.darstellen();
			sulley.addObserver(beobachter);
			sulley.kommunizieren();
			System.out.println();
		} else {
			System.out.println("Kein Handler gefunden");
		}
		
		System.out.println("Dependency Injection: Constructor Injection");
		Injector i = Guice.createInjector(new SpielgeneratorModul());
		Spielgenerator generator = i.getInstance(SpielgeneratorProvider.class).getSpielgenerator();
		Monster monster = generator.createKreatur();
		Gebaeude gebaeude = generator.createGebaeude();
		Gelaende gelaende = generator.createGelaende();
		monster.darstellen();
		gebaeude.darstellen();
		gelaende.darstellen();
		System.out.println();
	
		
	}
}
