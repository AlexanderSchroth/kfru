package monster;


import monster.fassade.Fassade;
import monster.fassade.MonsterTyp;
import monster.spielgenerator.SpielTyp;

public class MonsterTestDriveFassade {

	public static void main(String[] args) {
		Fassade f = new Fassade();
		
		f.initGame(SpielTyp.MONSTERWELT);
		f.spielzugDurchfuehren();
		f.hexeKommtEreignis();
		f.hexeGehtEreignis();
		f.erstelleMonster(MonsterTyp.DRACHE);
		f.spielzugDurchfuehren();
	}
}
