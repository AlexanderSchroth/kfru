package monster.verhalten;

public class WitzeErzaehlen implements Verhalten {

	public void kommunizieren() {
		System.out.println("Ich erzaehle Witze");
	}

}
