package monster.verhalten;

public class Verhaltensfabrik {

	public static Verhalten ermittleVerhalten(int schreckwert) {
		Verhalten verhalten = null;

		if (schreckwert > 0) {
			verhalten = new AngstMachen();
		} else if (schreckwert == 0) {
			verhalten = new Smalltalk();
		} else {
			verhalten = new WitzeErzaehlen();
		}

		return verhalten;
	}
}
