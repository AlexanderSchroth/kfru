package monster.verhalten;

public class AngstMachen implements Verhalten {

	public void kommunizieren() {
		System.out.println("Ich mache den Menschen Angst");
	}

}
