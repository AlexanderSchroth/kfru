package monster.verhalten;

public interface Verhalten {
	public void kommunizieren();
}
