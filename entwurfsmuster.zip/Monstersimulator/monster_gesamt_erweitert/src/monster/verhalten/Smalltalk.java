package monster.verhalten;

public class Smalltalk implements Verhalten {

	public void kommunizieren() {
		System.out.println("Ich mache Smalltalk");
	}

}
