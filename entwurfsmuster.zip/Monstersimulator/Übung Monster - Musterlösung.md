# Übung Monstersimulator



**Ausgangspunkt: Branch _monstersimulator-basis_**



1: Vorhanden:

- Abstrakte Monsterklasse: schreckwert, gegenstaende, addGegenstand(), darstellen(), berechneSchreckwert()
- Monsterklassen: darstellenMonster()

UML zeichnen



2: Vorhanden:

- Abstrakte Gegenstandsklasse: schreckwert, beschreibung
- Gegenstandsklassen

UML zeichnen



3: Verhalten -> Strategiemuster:

UML zeichnen

* Vorhanden: Interface Verhalten
* ToDo: Klassen für Verhalten: AngstMachen, Smalltalk, WitzeErzaehlen
* ToDo: Initiales Verhalten in den Monsterklassen - verhalten = new ... im Konstruktor
* ToDo: Aggregation in Monster
* ToDo: Methode kommunizieren() in Monster - Delegation
* ToDo: TestDrive - Kommentar bei kommunizieren entfernen
* ToDo: Dynamische Änderung des Verhaltens - ermittleVerhalten() und ergänzen bei addGegenstand

Code: monstersimulator-strategie



4: Benachrichtigung -> Beobachtermuster:

UML zeichnen

* Vorhanden: SchreckwertBeobachter
* ToDo: Ausgabe in SchreckwertBeobachter
* ToDo: Monster erbt von Observable
* ToDo: Notification in addGegenstand
* ToDo: TestDrive - Kommentar bei Observer und addObserver entfernen

Code: monstersimulator-beobachter



5: Benachrichtigung mit PropertyChange

* SchreckwertBeobachter ändern
* Monster: 
  * Attribut PropertyChangeSupport, initialisieren in Konstruktor
  * add/removePropertyChangeListener
  * addGegenstand: firePropertyChange
  * TestDrive: PropertyChangeListener / addProp....

Code: monstersimulator-propertychange



6: Wiederverwendung: Adapter

UML zeichnen

* Vorhanden: Interface Geist
* ToDo: Geisterklassen
* ToDo: GeistAdapter - Assoziation, Konstruktor (mit Verhalten), darstellenMonster()
* TestDrive: Kommentar bis Monsterfabrik entfernen, addObserver -> addProperty

Code: monstersimulator-adapter



7: Fabriken

UML zeichnen

* Monsterfabrik mit den 3 Monstern
* TestDrive: Kommentar bei Kobold und Fabrik entfernen
* Schreckliche und Lustige Monsterfabrik
* TestDrive: Kommentar bei SchrecklicheMonsterfabrik entfernen, Code für LustigeMonsterfabrik ergänzen
* Geisterfabrik
* TestDrive: Kommentar bei GeistAdapter entfernen
* Erweiterung MonsterFabrik um GeistAdapter
* TestDrive: Erweiterung für Poltergeist

Code: monstersimulator-fabriken



8: Spielgenerator - abstrakte Fabrik

UML zeichnen

* Vorhanden: Gebäude, Gelände, Interface Spielgenerator
* ToDo: Monsterspielgenerator
* ToDo: TestDrive - Kommentare entfernen
* ToDo: Geisterspielgenerator
* ToDo: TestDrive - Kommentare entfernen

Code: monstersimulator-spielgenerator



9: Zustandsmuster

UML zeichnen

* Neues Package zustaende
* Abstrakte Klasse Zustand mit den Ereignissen: aufstehen, schlafen ,arbeiten, ausruhen, essen, entry, exit
* Zustandsklassen schlafen, ausruhen, arbeiten, essen (extends Zustand) - entsprechende Ereignisse implementieren (noch ohne Code)
* Monster: Zustandsverwaltung - Attribute, Initialisierung in Konstruktor, Getter
* Monster: Aktueller Zustand (zustand) - Getter, Setter, Initialisierung in Konstruktor mit schlafen
* Monster: Ereignisse - Delegation
* Monster: Aktionen
* Zustände: Ereignisse implementieren

Code: monstersimulator-zustandsmuster (Commit part 1)



10: Zustandsmuster - Erweiterung

UML zeichnen

* Normalzustand und Kampfmodus, extends Zustand
* Bisherige Zustände erben von Normalzustand
* Neue Zustände Kämpfend und Heilend extends Kampfmodus
* Zustand: neue Ereignisse
* Monster: Verwaltung und Initialisierung neue Zustände
* Monster: Ereignisse und Aktionen
* Neue Zustände: Ereignisse implementieren
* TestDrive: restliche Kommentare entfernen