## Entwurfsmuster
Repository der Vorlesung _Entwurfsmuster_.