package aliensimulator.verhalten;

public class ErdeFeindlichBesuchen implements ErdeBesuchverhalten{

	public void erdeBesuchen() { System.out.println("Ich besuche die Erde. Die Menschen schmecken gut."); }
}
