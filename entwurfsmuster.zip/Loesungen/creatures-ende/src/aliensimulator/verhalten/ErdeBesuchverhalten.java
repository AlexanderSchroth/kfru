package aliensimulator.verhalten;

public interface ErdeBesuchverhalten {
	
	public void erdeBesuchen();
}
