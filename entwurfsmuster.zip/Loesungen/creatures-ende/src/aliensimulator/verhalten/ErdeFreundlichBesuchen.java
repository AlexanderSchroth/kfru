package aliensimulator.verhalten;

public class ErdeFreundlichBesuchen implements ErdeBesuchverhalten {
	
	public void erdeBesuchen (){
		System.out.println("Ich besuche die Erde. Die Menschen sind wundervoll.");
	};
}
