package creature;

import aliens.ErdeBesuchverhalten;

public abstract class Creature {

	public void fliegen() {
		System.out.println("Ich fliege durch den Weltraum.");
	}
	
	public abstract void darstellen();

	protected ErdeBesuchverhalten erdeBesuchverhalten;
	
	
	public void erdeBesuchen(){
		erdeBesuchverhalten.erdeBesuchen();
	}

	public void setErdeBesuchverhalten(ErdeBesuchverhalten erdeBesuchverhalten) {
		this.erdeBesuchverhalten = erdeBesuchverhalten;
	}

	public ErdeBesuchverhalten getErdeBesuchverhalten() {
		return erdeBesuchverhalten;
	}
}
