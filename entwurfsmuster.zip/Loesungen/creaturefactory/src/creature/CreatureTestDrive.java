package creature;

import aliens.AlienFactory;
import aliens.ErdeFreundlichBesuchen;
import predator.PredatorFactory;

public class CreatureTestDrive {

	public static void main(String[] args) {
		CreatureSimulator simulator = new CreatureSimulator(new AlienFactory());
		
		Creature alien1 = simulator.createCreature("mars");
		Creature alien2 = simulator.createCreature("mond");
		Creature alien3 = simulator.createCreature("venus");
	
		alien1.darstellen();
		alien1.fliegen();
		alien1.erdeBesuchen();
		
		alien2.darstellen();
		alien2.fliegen();
		alien2.erdeBesuchen();
		
		alien3.darstellen();
		alien3.fliegen();
		alien3.erdeBesuchen();
		
		//Aenderung zur Laufzeit des Verhaltens des Aliens vom Mars
		System.out.println("Verhalten vom Alien vom Mars VOR der �nderung seines Verhaltens:");
		alien1.erdeBesuchen();
		System.out.println("Verhalten vom Alien vom Mars NACH der �nderung seines Verhaltens:");
		alien1.setErdeBesuchverhalten(new ErdeFreundlichBesuchen());
		alien2.erdeBesuchen();
		
		Creature alienNY = simulator.createCreature("ny");
		alienNY.darstellen();
		alienNY.fliegen();
		alienNY.erdeBesuchen();
		
		
		simulator = new CreatureSimulator(new PredatorFactory());
		Creature predator = simulator.createCreature("yautja");
		predator.darstellen();
	}
	
}
