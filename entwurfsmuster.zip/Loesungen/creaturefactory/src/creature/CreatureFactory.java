package creature;

public abstract class CreatureFactory {

	public abstract Creature createCreature(String type);
}
