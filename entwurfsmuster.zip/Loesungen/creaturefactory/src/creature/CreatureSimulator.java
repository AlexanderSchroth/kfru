package creature;


public class CreatureSimulator {
	private CreatureFactory factory;
	
	public CreatureSimulator(CreatureFactory factory) {
		this.factory = factory;
	}
	
	public Creature createCreature(String type) {
		return factory.createCreature(type);
	}
}
