package predator;

import creature.Creature;

public abstract class Predator extends Creature {

}
