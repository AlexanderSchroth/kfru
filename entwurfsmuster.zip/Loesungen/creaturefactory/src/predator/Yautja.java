package predator;

public class Yautja extends Predator {

	@Override
	public void darstellen() {
		System.out.println("Ich bin ein Yautja.");
	}

}
