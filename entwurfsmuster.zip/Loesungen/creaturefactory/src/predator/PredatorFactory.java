package predator;

import creature.Creature;
import creature.CreatureFactory;

public class PredatorFactory extends CreatureFactory {

	@Override
	public Creature createCreature(String type) {
    	if (type.equals("yautja")) {
    		return new Yautja();
	} else if (type.equals("hishquten")) {
	    	return new HishQuTen();
	} else return null;
	}
}
