package predator;

public class HishQuTen extends Predator {

	@Override
	public void darstellen() {
		System.out.println("Ich bin ein Hish-Qu-Ten.");
	}

}
