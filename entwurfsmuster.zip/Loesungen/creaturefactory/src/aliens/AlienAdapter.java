package aliens;

import aliens_3rdparty.AlienFromNY;
import aliens_3rdparty.NeutralBesuchen;

public class AlienAdapter extends Alien {

	private AlienFromNY alienNY;

	public AlienAdapter(AlienFromNY alienNY) {
		this.alienNY = alienNY;
//		erdeBesuchverhalten = new ErdeNeutralAdapter(new NeutralBesuchen());
		erdeBesuchverhalten = new ErdeZerstoererischAdapter();
	}
	
	@Override
	public void darstellen() {
		alienNY.show();
	}

}
