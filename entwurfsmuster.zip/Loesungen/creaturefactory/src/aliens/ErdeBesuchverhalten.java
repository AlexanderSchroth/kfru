package aliens;

public interface ErdeBesuchverhalten {
	
	public void erdeBesuchen();
}
