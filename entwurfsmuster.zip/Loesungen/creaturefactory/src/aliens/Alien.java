package aliens;

import creature.Creature;

public abstract class Alien extends Creature {
	

}
