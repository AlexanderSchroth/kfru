package aliens_3rdparty;

public class AlienFromNY {
	public void show() {
		System.out.println("I'm the alien from New York.");
	}

	public void fly() {
		System.out.println("Flying to the moon ...");
	}

}
