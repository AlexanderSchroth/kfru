package aliens_3rdparty;

public class ZerstoererischBesuchen {

	public void zerstoere () {
		System.out.println("Ich werde euch vernichten ...");
	}
}
