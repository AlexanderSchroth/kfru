package aliens_3rdparty;

public class NeutralBesuchen {

	public void abwarten() {
		System.out.println("Schaun mer mal ...");
	}
}
