## Entwurfsmuster
Repository der Vorlesung _Entwurfsmuster_ im Modul _Methoden und Technologien professioneller Programmierung_.