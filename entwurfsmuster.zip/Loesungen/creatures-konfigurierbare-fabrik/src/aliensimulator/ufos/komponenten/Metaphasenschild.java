package aliensimulator.ufos.komponenten;

public class Metaphasenschild implements Schild {
    @Override
    public String toString() {
        return "Metaphasenschild";
    }
}