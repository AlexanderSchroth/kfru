package aliensimulator.ufos.komponenten;

public interface Schild {
    public String toString();
}
