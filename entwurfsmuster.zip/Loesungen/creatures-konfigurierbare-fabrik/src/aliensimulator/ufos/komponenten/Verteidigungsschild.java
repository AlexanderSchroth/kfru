package aliensimulator.ufos.komponenten;

public class Verteidigungsschild implements Schild {
    @Override
    public String toString() {
        return "Verteidigungsschild";
    }
}