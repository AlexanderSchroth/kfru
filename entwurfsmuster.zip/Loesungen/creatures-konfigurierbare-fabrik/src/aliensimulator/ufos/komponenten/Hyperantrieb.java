package aliensimulator.ufos.komponenten;

public class Hyperantrieb implements Antrieb {
    @Override
    public String toString() {
        return "Hyperantrieb";
    }
}
