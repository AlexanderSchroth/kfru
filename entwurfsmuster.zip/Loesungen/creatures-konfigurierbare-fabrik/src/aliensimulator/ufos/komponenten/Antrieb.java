package aliensimulator.ufos.komponenten;

public interface Antrieb {
    public String toString();
}
