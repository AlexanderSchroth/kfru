package aliensimulator.ufos.komponenten;

public class Laserkanone implements Waffe {
    @Override
    public String toString() {
        return "Laserkanone";
    }
}