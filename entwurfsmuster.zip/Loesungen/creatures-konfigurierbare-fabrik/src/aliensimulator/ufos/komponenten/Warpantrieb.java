package aliensimulator.ufos.komponenten;

public class Warpantrieb implements Antrieb {
    @Override
    public String toString() {
        return "Warpantrieb";
    }
}
