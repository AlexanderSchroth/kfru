package aliensimulator.ufos.komponenten;

public class Phaserkanone implements Waffe {
    @Override
    public String toString() {
        return "Phaserkanone";
    }
}