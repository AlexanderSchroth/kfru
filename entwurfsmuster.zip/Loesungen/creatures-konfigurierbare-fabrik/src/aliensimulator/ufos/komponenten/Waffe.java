package aliensimulator.ufos.komponenten;

public interface Waffe {
    public String toString();
}
