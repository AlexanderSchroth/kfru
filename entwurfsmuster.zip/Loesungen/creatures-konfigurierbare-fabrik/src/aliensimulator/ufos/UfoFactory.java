package aliensimulator.ufos;

public interface UfoFactory {

    public Ufo createUfo(String type);

}
