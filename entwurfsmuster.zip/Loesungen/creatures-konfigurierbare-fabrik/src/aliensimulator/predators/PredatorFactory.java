package aliensimulator.predators;


import java.io.IOException;
import java.util.Properties;

public class PredatorFactory {
	private Properties properties = new Properties();

	public PredatorFactory() {
		try {
			properties.load(this.getClass().getResourceAsStream("factory.properties"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	public Predator createPredator(String type) {
		String handlerName = properties.getProperty(type);
		Class<?> classOfProtocolHandler = null;
		Predator predator = null;
		try {
			classOfProtocolHandler = Class.forName(handlerName);
			predator = (Predator) classOfProtocolHandler.newInstance();
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		} catch (InstantiationException e) {
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		return predator;
	}
}
