package wetterstation5;

public interface Beobachter {
	public void aktualisieren(float temp, float feucht, float druck);
}
