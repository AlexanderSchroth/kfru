package wetterstation9;

public abstract class SensorDaten {

}
