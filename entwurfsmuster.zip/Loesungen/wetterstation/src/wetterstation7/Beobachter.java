package wetterstation7;

public interface Beobachter {
	public void aktualisieren();
}
