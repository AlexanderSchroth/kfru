package wetterstation10;

public abstract class SensorDaten {

}
