package wetterstation6;

public interface Beobachter {
	public void aktualisieren(Subjekt s);
}
