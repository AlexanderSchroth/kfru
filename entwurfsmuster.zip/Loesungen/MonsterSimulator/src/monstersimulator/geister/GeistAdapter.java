package monstersimulator.geister;

import monstersimulator.monster.Monster;

public class GeistAdapter extends Monster {
    private final Geist geist;

    public GeistAdapter(Geist geist) {
        super(2);
        this.geist = geist;
        ermittleVerhalten();
    }

    @Override
    public void darstellen() {
        geist.anzeigen();
    }
}
