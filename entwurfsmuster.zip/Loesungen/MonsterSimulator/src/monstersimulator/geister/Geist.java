package monstersimulator.geister;

public abstract class Geist {

    abstract void anzeigen();

}
