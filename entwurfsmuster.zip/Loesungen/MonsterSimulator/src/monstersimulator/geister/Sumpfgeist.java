package monstersimulator.geister;

public class Sumpfgeist extends Geist {
    @Override
    void anzeigen() {
        System.out.println("ich bin ein Sumpfgeist");
    }
}
