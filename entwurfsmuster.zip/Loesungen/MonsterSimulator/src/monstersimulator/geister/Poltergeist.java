package monstersimulator.geister;

public class Poltergeist extends Geist {

    @Override
    void anzeigen() {
        System.out.println("ich bin ein Poltergeist");
    }
}
