package monstersimulator.gegenstaende;

public class Clownsnase extends Gegenstand {
    public Clownsnase() {
        super(-2);
    }
}
