package monstersimulator.gegenstaende;

public class Hexenmaske extends Gegenstand {


    public Hexenmaske() {
        super(2);
    }
}
