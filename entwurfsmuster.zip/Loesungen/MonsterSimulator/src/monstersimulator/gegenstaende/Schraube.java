package monstersimulator.gegenstaende;

public class Schraube extends Gegenstand {
    public Schraube() {
        super(0);
    }
}
