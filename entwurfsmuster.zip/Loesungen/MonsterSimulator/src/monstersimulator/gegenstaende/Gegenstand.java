package monstersimulator.gegenstaende;

public class Gegenstand {

   private int schreckWertModifier;

    public Gegenstand(int schreckWertModifier) {
        this.schreckWertModifier = schreckWertModifier;
    }

    public int getSchreckWertModifier() {
        return schreckWertModifier;
    }
}
