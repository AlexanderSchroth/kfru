package monstersimulator.gegenstaende;

public class FrankensteinSchraube extends Gegenstand {
    public FrankensteinSchraube() {
        super(1);
    }
}
