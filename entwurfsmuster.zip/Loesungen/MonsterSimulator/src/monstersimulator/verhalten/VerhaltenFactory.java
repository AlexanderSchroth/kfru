package monstersimulator.verhalten;

public class VerhaltenFactory {

    public static Verhalten createVerhalten(int schreckWert) {
        if (schreckWert == 0) {
            return new Smalltalk();
        } else if (schreckWert < 0) {
            return new Witzerzaehlen();
        } else {
            return new AngstMachen();
        }

    }

}
