package monstersimulator.verhalten;

public class Witzerzaehlen extends Verhalten {
    @Override
    public void kommunizieren() {
        System.out.println("ich erzaehle einen Witz");
    }
}
