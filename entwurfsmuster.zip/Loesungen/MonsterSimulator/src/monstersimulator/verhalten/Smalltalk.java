package monstersimulator.verhalten;

public class Smalltalk extends Verhalten {
    @Override
    public void kommunizieren() {
        System.out.println("ich mache smalltalk");
    }
}
