package monstersimulator.verhalten;

public abstract class Verhalten {

    public abstract void kommunizieren();

}
