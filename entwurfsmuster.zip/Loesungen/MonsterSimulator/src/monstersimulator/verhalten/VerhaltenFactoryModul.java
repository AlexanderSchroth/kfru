//package monstersimulator.verhalten;
//
//import com.google.inject.AbstractModule;
//
//public class VerhaltenFactoryModul extends AbstractModule {
//    @Override
//    public void configure() {
//        bind(VerhaltenFactory.class).to(DefaultVerhaltenFactoryImpl.class);
//    }
//}
