package monstersimulator;

import com.google.inject.Guice;
import com.google.inject.Injector;
import monstersimulator.gegenstaende.Clownsnase;
import monstersimulator.gegenstaende.FrankensteinSchraube;
import monstersimulator.gegenstaende.Hexenmaske;
import monstersimulator.monster.Drache;
import monstersimulator.monster.Kobold;
import monstersimulator.monster.Kruemelmonster;
import monstersimulator.monster.Monster;
import monstersimulator.monster.MonsterFabrik;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

//        Injector injector = Guice.createInjector(new VerhaltenFactoryModul());
//        Kobold kobold = injector.getInstance(Kobold.class);
//        VerhaltenFactory instance = injector.getInstance(VerhaltenFactory.class);
//        System.out.println(kobold);

        Oberflaeche oberflaeche = new Oberflaeche();
        VerhaltenHandler verhaltenHandler = new VerhaltenHandler();

        Kobold kobold = new Kobold();
        kobold.addObserver(oberflaeche);
        kobold.addObserver(verhaltenHandler);
        kobold.aufnehmen(new Clownsnase());
        kobold.darstellen();
        System.out.println("Kobold mit Clownsnase hat Schreckwert: " + kobold.getSchreckWert());
        kobold.kommuniziere();

        Kruemelmonster kruemelmonster = new Kruemelmonster();
        kruemelmonster.addObserver(oberflaeche);
        kruemelmonster.addObserver(verhaltenHandler);
        kruemelmonster.aufnehmen(new Hexenmaske());
        kruemelmonster.aufnehmen(new Hexenmaske());
        kruemelmonster.aufnehmen(new Hexenmaske());
        kruemelmonster.darstellen();
        kruemelmonster.kommuniziere();


        Drache drache = new Drache();
        drache.addObserver(oberflaeche);
        drache.addObserver(verhaltenHandler);
        drache.aufnehmen(new FrankensteinSchraube());
        drache.darstellen();
        drache.kommuniziere();


        Monster sumpfgeist = MonsterFabrik.getMonster("Sumpfgeist");
        sumpfgeist.darstellen();
        sumpfgeist.kommuniziere();
    }
}