package monstersimulator;

import monstersimulator.monster.Monster;

import java.util.Observable;
import java.util.Observer;

public class VerhaltenHandler implements Observer {


    @Override
    public void update(Observable o, Object arg) {
        Monster monster = (Monster) o;
        monster.ermittleVerhalten();
    }
}
