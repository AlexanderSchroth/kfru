package monstersimulator;

import monstersimulator.monster.Monster;

import java.util.Observable;
import java.util.Observer;

public class Oberflaeche implements Observer {

    @Override
    public void update(Observable o, Object arg) {
        System.out.println("update der UI, neuer schreckwert " + arg + " " + (o.getClass()));
    }
}
