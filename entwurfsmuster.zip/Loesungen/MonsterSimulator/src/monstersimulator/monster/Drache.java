package monstersimulator.monster;

public class Drache extends Monster {
    public Drache() {
        super(5);
    }

    @Override
    public void darstellen() {
        System.out.println("ich bin ein Drache!");
    }
}
