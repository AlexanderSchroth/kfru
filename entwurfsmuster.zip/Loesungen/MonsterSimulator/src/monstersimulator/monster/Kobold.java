package monstersimulator.monster;

public class Kobold extends Monster {
    public Kobold() {
        super(0);
    }

    @Override
    public void darstellen() {
        System.out.println("Ich bin ein Kobold.");
    }
}
