package monstersimulator.monster;

public class Kruemelmonster extends Monster {
    public Kruemelmonster() {
        super(-5);
    }

    @Override
    public void darstellen() {
        System.out.println("Ich bin ein Kruemelmonster");
    }
}
