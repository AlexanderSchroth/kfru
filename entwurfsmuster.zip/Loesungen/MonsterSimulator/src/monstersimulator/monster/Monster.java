package monstersimulator.monster;

import com.google.inject.Inject;
import monstersimulator.gegenstaende.Gegenstand;
import monstersimulator.verhalten.Verhalten;
import monstersimulator.verhalten.VerhaltenFactory;

import java.util.ArrayList;
import java.util.Observable;

public abstract class Monster extends Observable {

    public int schreckWert;

    private Verhalten verhalten;
    final ArrayList<Gegenstand> gegenstaende;

    @Inject
    public Monster(int basisSchreckWert) {
        this.schreckWert = basisSchreckWert;
        gegenstaende = new ArrayList<>();
    }

    public abstract void darstellen();

    public void aufnehmen(Gegenstand gegenstand) {
        gegenstaende.add(gegenstand);
        int schreckWertModifier = gegenstand.getSchreckWertModifier();
        if (schreckWertModifier != 0) {
            this.schreckWert += schreckWertModifier;
            setChanged();
        }
        notifyObservers(this.schreckWert);
    }

    public int getSchreckWert() {
        return schreckWert;
    }

    public void ermittleVerhalten() {
        verhalten = VerhaltenFactory.createVerhalten(getSchreckWert());
    }

    public void kommuniziere() {
        verhalten.kommunizieren();
    }
}
