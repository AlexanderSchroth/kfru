package monstersimulator.monster;

import monstersimulator.geister.GeistAdapter;
import monstersimulator.geister.Sumpfgeist;

public class MonsterFabrik {



    public static Monster getMonster(String monsterName) {
        Monster monster=null;
        if (monsterName.equals("Sumpfgeist")) {
         return new GeistAdapter(new Sumpfgeist());
        }else {
            return monster;
        }
    }

}
