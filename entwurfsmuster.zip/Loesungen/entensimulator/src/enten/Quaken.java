package enten;

public class Quaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("Quak");
	}
}
