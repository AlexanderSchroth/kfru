package enten;

public class Quietschen implements QuakVerhalten {
	public void quaken() {
		System.out.println("Quietsch");
	}
}
