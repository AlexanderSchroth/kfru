package enten;

public abstract class Ente {
	FlugVerhalten flugVerhalten;
	QuakVerhalten quakVerhalten;
 
	public void setFlugVerhalten (FlugVerhalten fv) {
		flugVerhalten = fv;
	}
 
	public void setQuakVerhalten(QuakVerhalten qv) {
		quakVerhalten = qv;
	}
 
	abstract void anzeigen();
 
	public void fliegen() {
		flugVerhalten.fliegen();
	}
 
	public void quaken() {
		quakVerhalten.quaken();
	}
 
	public void schwimmen() {
		System.out.println("Alle Enten schwimmen, auch Holzenten!");
	}
}
