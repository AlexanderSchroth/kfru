package enten;

public interface QuakVerhalten {
	public void quaken();
}
