package enten;

public class StummesQuaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("<< Stille >>");
	}
}
