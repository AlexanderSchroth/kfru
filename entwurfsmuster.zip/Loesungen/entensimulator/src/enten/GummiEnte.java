package enten;

public class GummiEnte extends Ente {
 
	public GummiEnte() {
		super();
		flugVerhalten = new FliegtGarNicht();
		quakVerhalten = new Quietschen();
	}
 
	public void anzeigen() {
		System.out.println("Ich bin eine Gummi-Ente");
	}
}
