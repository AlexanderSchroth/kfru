package enten;

public class VorgetaeuschtesQuaken implements QuakVerhalten {
	public void quaken() {
		System.out.println("Quark");
	}
}
