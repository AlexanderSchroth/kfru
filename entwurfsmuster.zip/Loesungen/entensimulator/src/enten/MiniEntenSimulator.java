package enten;

public class MiniEntenSimulator {
 
	public static void main(String[] args) {
 
		StockEnte stockente = new StockEnte();
		GummiEnte gummiEntchen = new GummiEnte();
		LockEnte lockente = new LockEnte();
 		ModellEnte modellEnte = new ModellEnte();

		stockente.quaken();
		gummiEntchen.quaken();
		lockente.quaken();
   
		modellEnte.fliegen();	
		modellEnte.setFlugVerhalten(new FliegtRaketenGetrieben());
		modellEnte.fliegen();
		modellEnte.schwimmen();
	}
}
