package enten;

public class MoorEnte extends Ente {
 
	public MoorEnte() {
		super();
		flugVerhalten = new FliegtMitFluegeln();
		quakVerhalten = new Quaken();
	}
 
	public void anzeigen() {
		System.out.println("Ich bin eine echte Moorente");
	}
}
