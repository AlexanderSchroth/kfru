package enten;

public class ModellEnte extends Ente {
	
	public ModellEnte() {
		super();
		flugVerhalten = new FliegtGarNicht();
		quakVerhalten = new Quaken();
	}

	public void anzeigen() {
		System.out.println("Ich bin eine Modell-Ente");
	}
}
