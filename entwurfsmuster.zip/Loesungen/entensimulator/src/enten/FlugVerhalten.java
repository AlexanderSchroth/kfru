package enten;

public interface FlugVerhalten {
	public void fliegen();
}
