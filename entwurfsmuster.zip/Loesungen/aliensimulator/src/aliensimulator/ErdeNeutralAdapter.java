package aliensimulator;

import aliens_3rdparty.NeutralBesuchen;

public class ErdeNeutralAdapter implements ErdeBesuchverhalten {

	private NeutralBesuchen neutral;
	
	public ErdeNeutralAdapter(NeutralBesuchen neutral) {
		this.neutral = neutral;
	}
	
	@Override
	public void erdeBesuchen() {
		neutral.abwarten();
	}

	
}
