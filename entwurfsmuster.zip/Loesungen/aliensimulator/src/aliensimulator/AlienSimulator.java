package aliensimulator;

import aliens_3rdparty.AlienFromNY;

public class AlienSimulator {
	
	public static void main(String[] args) {
		Alien alien1 = new AlienMars();
		Alien alien2 = new AlienMond();
		Alien alien3 = new AlienVenus();
	
		alien1.darstellen();
		alien1.fliegen();
		alien1.erdeBesuchen();
		
		alien2.darstellen();
		alien2.fliegen();
		alien2.erdeBesuchen();
		
		alien3.darstellen();
		alien3.fliegen();
		alien3.erdeBesuchen();
		
		//Aenderung zur Laufzeit des Verhaltens des Aliens vom Mars
		System.out.println("Verhalten vom Alien vom Mars VOR der �nderung seines Verhaltens:");
		alien1.erdeBesuchen();
		System.out.println("Verhalten vom Alien vom Mars NACH der �nderung seines Verhaltens:");
		alien1.setErdeBesuchverhalten(new ErdeFreundlichBesuchen());
		alien2.erdeBesuchen();
		
		Alien alienAdapter = new AlienAdapter(new AlienFromNY());
		alienAdapter.darstellen();
		alienAdapter.fliegen();
		alienAdapter.erdeBesuchen();
	}
}
