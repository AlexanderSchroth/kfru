package aliensimulator;

public abstract class Alien {
	
	protected ErdeBesuchverhalten erdeBesuchverhalten;
	
	public void fliegen() {
		System.out.println("Ich fliege durch den Weltraum.");
	}
	
	abstract void darstellen();
	
	public void erdeBesuchen(){
		erdeBesuchverhalten.erdeBesuchen();
	}

	public void setErdeBesuchverhalten(ErdeBesuchverhalten erdeBesuchverhalten) {
		this.erdeBesuchverhalten = erdeBesuchverhalten;
	}

	public ErdeBesuchverhalten getErdeBesuchverhalten() {
		return erdeBesuchverhalten;
	}
}
