package aliensimulator;

public interface ErdeBesuchverhalten {
	
	public void erdeBesuchen();
}
