package creature;

import com.google.inject.Guice;
import com.google.inject.Injector;

import aliens.ErdeFreundlichBesuchen;

public class CreatureTestDrive {

	public static void main(String[] args) {
		Injector i = Guice.createInjector(new CreatureSimulatorModule());
		CreatureSimulator simulator = i.getInstance(CreatureSimulator.class);
		
		// Alien-Testcode
		Creature alien = simulator.createCreature("mars");
	
		alien.darstellen();
		alien.fliegen();
		alien.erdeBesuchen();
		
		//Aenderung zur Laufzeit des Verhaltens des Aliens vom Mars
		System.out.println("Verhalten vom Alien vom Mars VOR der �nderung seines Verhaltens:");
		alien.erdeBesuchen();
		System.out.println("Verhalten vom Alien vom Mars NACH der �nderung seines Verhaltens:");
		alien.setErdeBesuchverhalten(new ErdeFreundlichBesuchen());
		alien.erdeBesuchen();
		
		Creature alienNY = simulator.createCreature("ny");
		alienNY.darstellen();
		alienNY.fliegen();
		alienNY.erdeBesuchen();
		
		// Predator-Testcode
//		Creature predator = simulator.createCreature("yautja");
//		predator.darstellen();
	}
	
}
