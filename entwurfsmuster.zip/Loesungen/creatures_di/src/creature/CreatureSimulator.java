package creature;

import com.google.inject.Inject;

public class CreatureSimulator {
	private CreatureFactory factory;
	
	@Inject
	public CreatureSimulator(CreatureFactory factory) {
		this.factory = factory;
	}
	
	public Creature createCreature(String type) {
		return factory.createCreature(type);
	}
}
