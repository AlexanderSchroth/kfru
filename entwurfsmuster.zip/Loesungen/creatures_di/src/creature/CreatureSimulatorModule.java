package creature;

import com.google.inject.AbstractModule;

import aliens.AlienFactory;
import predator.PredatorFactory;

public class CreatureSimulatorModule extends AbstractModule {

	protected void configure() {
		bind(CreatureFactory.class)
				 .to(AlienFactory.class);
//				.to(PredatorFactory.class);
	}

}
