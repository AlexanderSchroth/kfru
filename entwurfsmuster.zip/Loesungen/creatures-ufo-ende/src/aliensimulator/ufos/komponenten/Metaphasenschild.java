package aliensimulator.ufos.komponenten;

public class Metaphasenschild extends Warpantrieb implements Schild {
    @Override
    public String toString() {
        return "Metaphasenschild";
    }
}