// startBot.js
const BotPlayer = require('./BotPlayer');

// URL deines WebSocket-Servers
const SERVER_URL = 'ws://157.90.117.79:8080';

// Optional: Spieler-Typ auswählen (Standard ist 'Kobold')
const PLAYER_TYPE = 'Kobold';

// Erstelle eine neue BotPlayer-Instanz
const bot = new BotPlayer(SERVER_URL, PLAYER_TYPE);
