// BotPlayer.js
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid'); // Für eindeutige Spieler-IDs

class BotPlayer {
    /**
     * Erstellt eine neue BotPlayer-Instanz.
     * @param {string} serverUrl - Die URL des WebSocket-Servers (z.B. ws://localhost:8080).
     * @param {string} type - Der Typ des Spielers (z.B. 'Kobold', 'Krümelmonster').
     */
    constructor(serverUrl, type = 'Kobold') {
        this.serverUrl = serverUrl;
        this.type = type;
        this.playerId = uuidv4(); // Eindeutige ID für den Bot
        this.ws = null;
        this.position = this.getRandomPosition(); // Startposition
        this.items = []; // Liste der aktuellen Gegenstände auf dem Spielfeld
        this.targetItem = null; // Aktuelles Zielgegenstand
        this.moveInterval = null; // Intervall für Bewegungen
        this.isCommunicating = false; // Flag, ob sich der Bot gerade bewegt, um 5 Felder weg zu gehen

        this.connect();
    }

    /**
     * Stellt die Verbindung zum WebSocket-Server her und richtet die Event-Listener ein.
     */
    connect() {
        this.ws = new WebSocket(this.serverUrl);

        this.ws.on('open', () => {
            console.log(`BotPlayer ${this.playerId} verbunden zu ${this.serverUrl}`);
            this.joinGame();
        });

        this.ws.on('message', (message) => {
            this.handleMessage(message);
        });

        this.ws.on('close', () => {
            console.log(`BotPlayer ${this.playerId} getrennt`);
            clearInterval(this.moveInterval);
            // Optional: Implementiere eine automatische Wiederverbindung
        });

        this.ws.on('error', (error) => {
            console.error(`BotPlayer ${this.playerId} WebSocket-Fehler: ${error}`);
        });
    }

    /**
     * Sendet den 'player_joined' Befehl an den Server, um dem Spiel beizutreten.
     */
    joinGame() {
        const joinCommand = {
            type: 'player_joined',
            playerId: this.playerId,
            position: this.position,
            payload: { type: this.type }
        };
        this.ws.send(JSON.stringify(joinCommand));
        console.log(`BotPlayer ${this.playerId} hat 'player_joined' Befehl gesendet`);
    }

    /**
     * Verarbeitet empfangene Nachrichten vom Server.
     * @param {string} message - Die empfangene Nachricht als JSON-String.
     */
    handleMessage(message) {
        let command;
        try {
            command = JSON.parse(message);
        } catch (e) {
            console.error(`BotPlayer ${this.playerId} erhielt ungültiges JSON: ${message}`);
            return;
        }

        // Behandle verschiedene Arten von Befehlen
        switch (command.type) {
            case 'darstellen':
                this.updateGameState(command.state);
                break;
            case 'item_created':
                this.items.push(command.item);
                console.log(`BotPlayer ${this.playerId} registriert neuen Gegenstand: ${command.item.type} an Position (${command.item.position.x}, ${command.item.position.y})`);
                break;
            case 'item_picked':
                if (command.playerId === this.playerId) {
                    console.log(`BotPlayer ${this.playerId} hat Gegenstand aufgenommen: ${command.item.type} an Position (${command.item.position.x}, ${command.item.position.y})`);
                    // Entferne den Gegenstand aus der lokalen Liste
                    this.items = this.items.filter(item =>
                        !(item.position.x === command.item.position.x && item.position.y === command.item.position.y)
                    );
                    this.targetItem = null; // Suche ein neues Ziel
                }
                break;
            case 'kommunizieren':
                this.handleKommunizierenEvent(command);
                break;
            // Weitere Befehle können hier hinzugefügt werden
            default:
                // Andere Befehle werden ignoriert oder können hier behandelt werden
                break;
        }
    }

    /**
     * Handhabt das 'kommunizieren' Ereignis, indem der Bot sich 5 Felder von der aktuellen Position entfernt bewegt.
     * @param {Object} command - Das 'kommunizieren' Ereignis.
     */
    handleKommunizierenEvent(command) {
        console.log(`BotPlayer ${this.playerId} empfängt 'kommunizieren' Ereignis:`, command);
        // ignoriere das event wenn nicht der bot kommuniziert
        if (!command.players.includes(this.playerId)) {
            console.log(`BotPlayer ${this.playerId} ist nicht betroffen von 'kommunizieren' Ereignis. Ignoriere.`);
            return;
        }

        console.log(`BotPlayer ${this.playerId} - ${command.players}`);



        if (this.isCommunicating) {
            console.log(`BotPlayer ${this.playerId} ist bereits dabei, sich zu bewegen. Ignoriere weiteres 'kommunizieren' Ereignis.`);
            return;
        }

        this.isCommunicating = true;

        let steps = 0;
        const maxSteps = 5;
        const moveInterval = setInterval(() => {
            if (steps >= maxSteps) {
                clearInterval(moveInterval);
                this.isCommunicating = false;
                this.targetItem = null; // Suche ein neues Ziel nach dem Wegbewegen
                return;
            }
            this.moveRandomly();
            steps++;
        }, 100); // Bewege alle 500 ms
    }

    /**
     * Aktualisiert den lokalen Spielzustand basierend auf dem 'darstellen' Ereignis.
     * @param {Object} state - Der aktuelle Spielzustand.
     */
    updateGameState(state) {
        // Aktualisiere die Liste der Gegenstände
        this.items = state.items;
        // Aktualisiere die eigene Position
        const playerData = state.players.find(p => p.playerId === this.playerId);
        if (playerData) {
            this.position = playerData.position;
        }

        // Starte die Bewegungslogik, falls noch nicht gestartet
        if (!this.moveInterval) {
            this.startMoving();
        }
    }

    /**
     * Startet die Bewegungslogik des Bots in regelmäßigen Abständen.
     */
    startMoving() {
        this.moveInterval = setInterval(() => {
            // Wenn der Bot gerade kommuniziert und sich bewegt, überspringe diesen Zyklus
            if (this.isCommunicating) {
                return;
            }

            // // Wähle das nächste Ziel, falls keines gesetzt oder das Ziel nicht mehr existiert
            // if (!this.targetItem || !this.items.find(item =>
            //     item.position.x === this.targetItem.position.x &&
            //     item.position.y === this.targetItem.position.y
            // )) {
                this.targetItem = this.findNearestItem();
            // }

            if (this.targetItem) {
                this.moveTowards(this.targetItem.position);
            } else {
                // Keine Gegenstände vorhanden, bewege dich zufällig
                this.moveRandomly();
            }
        }, 1000); // Alle 1 Sekunde bewegen
    }

    /**
     * Findet den nächsten Gegenstand basierend auf der Manhattan-Distanz.
     * @returns {Object|null} - Der nächste Gegenstand oder null, wenn keine vorhanden sind.
     */
    findNearestItem() {
        if (this.items.length === 0) return null;

        let nearest = this.items[0];
        let minDist = this.manhattanDistance(this.position, nearest.position);

        for (let item of this.items) {
            const dist = this.manhattanDistance(this.position, item.position);
            if (dist < minDist) {
                nearest = item;
                minDist = dist;
            }
        }

        console.log(`BotPlayer ${this.playerId} hat Zielgegenstand: ${nearest.type} an Position (${nearest.position.x}, ${nearest.position.y})`);
        return nearest;
    }

    /**
     * Berechnet die Manhattan-Distanz zwischen zwei Positionen.
     * @param {Object} pos1 - { x: Number, y: Number }
     * @param {Object} pos2 - { x: Number, y: Number }
     * @returns {Number} - Die Manhattan-Distanz.
     */
    manhattanDistance(pos1, pos2) {
        return Math.abs(pos1.x - pos2.x) + Math.abs(pos1.y - pos2.y);
    }

    /**
     * Bewegt den Bot in Richtung des Zielgegenstands.
     * @param {Object} targetPosition - Die Position des Zielgegenstands.
     */
    moveTowards(targetPosition) {
        if (this.position.x < targetPosition.x) {
            this.position.x += 1;
            this.sendMoveCommand('right');
        } else if (this.position.x > targetPosition.x) {
            this.position.x -= 1;
            this.sendMoveCommand('left');
        }
        if (this.position.y < targetPosition.y) {
            this.position.y += 1;
            this.sendMoveCommand('down');
        } else if (this.position.y > targetPosition.y) {
            this.position.y -= 1;
            this.sendMoveCommand('up');
        }
    }

    /**
     * Bewegt den Bot zufällig in eine der vier Richtungen.
     */
    moveRandomly() {
        const directions = ['up', 'down', 'left', 'right'];
        const direction = directions[Math.floor(Math.random() * directions.length)];

        // Aktualisiere die Position basierend auf der Richtung
        switch (direction) {
            case 'up':
                this.position.y = Math.max(0, this.position.y - 1);
                break;
            case 'down':
                this.position.y = Math.min(24, this.position.y + 1); // Annahme: FIELD_HEIGHT = 25
                break;
            case 'left':
                this.position.x = Math.max(0, this.position.x - 1);
                break;
            case 'right':
                this.position.x = Math.min(24, this.position.x + 1); // Annahme: FIELD_WIDTH = 25
                break;
            default:
                break;
        }
        this.sendMoveCommand(direction);
    }

    /**
     * Sendet einen 'move' Befehl an den Server, inklusive aktueller Position.
     * @param {string} direction - Die Richtung ('up', 'down', 'left', 'right').
     */
    sendMoveCommand(direction) {
        const moveCommand = {
            type: 'move',
            playerId: this.playerId,
            payload: { direction: direction },
            position: { x: this.position.x, y: this.position.y } // Aktuelle Position hinzufügen
        };
        this.ws.send(JSON.stringify(moveCommand));
        console.log(`BotPlayer ${this.playerId} sendet 'move' Befehl: ${direction} von Position (${this.position.x}, ${this.position.y})`);
    }

    /**
     * Generiert eine zufällige Startposition innerhalb des Spielfelds.
     * @returns {Object} - { x: Number, y: Number }
     */
    getRandomPosition() {
        // Annahme: Spielfeldgröße ist 25x25, kann angepasst werden
        const FIELD_WIDTH = 25;
        const FIELD_HEIGHT = 25;
        return {
            x: Math.floor(Math.random() * FIELD_WIDTH),
            y: Math.floor(Math.random() * FIELD_HEIGHT)
        };
    }

    /**
     * Bewegt den Bot in eine zufällige Richtung, bis er 5 Felder bewegt hat.
     * @param {string} direction - Die Richtung ('up', 'down', 'left', 'right').
     */
    moveAway(direction) {
        let steps = 0;
        const maxSteps = 5;
        const moveInterval = setInterval(() => {
            if (steps >= maxSteps) {
                clearInterval(moveInterval);
                this.isCommunicating = false;
                this.targetItem = null; // Suche ein neues Ziel nach dem Wegbewegen
                return;
            }
            this.sendMoveCommand(direction);
            steps++;
        }, 500); // Bewege alle 500 ms
    }
}

module.exports = BotPlayer;
