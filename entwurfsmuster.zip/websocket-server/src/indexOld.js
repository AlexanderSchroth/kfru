const WebSocket = require('ws');

// Port, auf dem der Server lauscht
const PORT = 8080;

// Maximale Anzahl gespeicherter Befehle
const MAX_COMMANDS = 10000;

// Array zum Speichern der letzten Befehle
const commandHistory = [];

// Erstellen eines neuen WebSocket-Servers
const wss = new WebSocket.Server({ port: PORT }, () => {
    console.log(`WebSocket-Server läuft auf ws://localhost:${PORT}`);
});

// Map zur Zuordnung von WebSocket-Verbindungen zu playerIds
const wsPlayerMap = new Map();

// Verbindung bei jedem neuen Client
wss.on('connection', (ws) => {
    console.log('Neuer Client verbunden');

    // Senden der letzten 200 Befehle an den neuen Client
    commandHistory.forEach((command) => {
        ws.send(JSON.stringify(command));
    });

    // Empfang von Nachrichten vom Client
    ws.on('message', (message) => {
        console.log(`Empfangene Nachricht: ${message}`);

        let command;
        try {
            command = JSON.parse(message);
        } catch (e) {
            console.error('Ungültiges JSON:', e);
            ws.send(JSON.stringify({ error: 'Ungültiges JSON-Format' }));
            return;
        }

        // Validierung des Befehls
        if (validateCommand(command)) {
            const { playerId } = command;

            // Mappe die WebSocket-Verbindung auf die playerId
            wsPlayerMap.set(ws, playerId);

            // Speichern des Befehls in der Historie
            commandHistory.push(command);
            if (commandHistory.length > MAX_COMMANDS) {
                commandHistory.shift(); // Entfernt den ältesten Befehl
            }

            // Broadcast des Befehls an alle verbundenen Clients
            broadcast(JSON.stringify(command));
        } else {
            ws.send(JSON.stringify({ error: 'Ungültige Befehlsstruktur' }));
        }
    });

    // Verbindung schließen
    ws.on('close', () => {
        console.log('Client getrennt');
        const playerId = wsPlayerMap.get(ws);
        if (playerId) {
            wsPlayerMap.delete(ws);
            const playerLeftCommand = {
                type: 'player_left',
                playerId: playerId,
                timestamp: getCurrentTimestamp()
            };
            const playerLeftJson = JSON.stringify(playerLeftCommand);

            // Speichern des 'player_left' Kommandos in der Historie
            commandHistory.push(playerLeftCommand);
            if (commandHistory.length > MAX_COMMANDS) {
                commandHistory.shift(); // Entfernt den ältesten Befehl
            }

            // Broadcast des 'player_left' Kommandos an alle verbundenen Clients
            broadcast(playerLeftJson);
            console.log(`Spieler verlassen: ${playerId}`);
        }
    });

    // Fehlerbehandlung
    ws.on('error', (error) => {
        console.error(`WebSocket-Fehler: ${error}`);
    });
});

/**
 * Validiert die Struktur des empfangenen Spielbefehls.
 * Erlaubt beliebige 'type' Werte, solange 'playerId' vorhanden ist.
 * @param {Object} command - Der Spielbefehl.
 * @returns {boolean} - Gibt true zurück, wenn der Befehl gültig ist.
 */
function validateCommand(command) {
    if (typeof command !== 'object' || command === null) {
        return false;
    }

    if (typeof command.playerId !== 'string' || command.playerId.trim() === '') {
        return false;
    }

    if (typeof command.type !== 'string' || command.type.trim() === '') {
        return false;
    }

    // Optional: Überprüfen Sie zusätzliche Felder basierend auf 'type'
    // Zum Beispiel, wenn 'type' === 'move', können Sie zusätzliche Validierungen durchführen
    // Dies hängt von den spezifischen Anforderungen Ihrer Anwendung ab

    return true;
}

/**
 * Sendet eine Nachricht an alle verbundenen Clients.
 * @param {string} data - Die zu sendende Nachricht.
 */
function broadcast(data) {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(data);
        }
    });
}

/**
 * Gibt den aktuellen Timestamp in ISO 8601 Format zurück, angepasst an die deutsche Zeitzone.
 * @returns {string} - Der formatierte Timestamp.
 */
function getCurrentTimestamp() {
    const now = new Date();
    // Deutschland befindet sich in der Zeitzone "Europe/Berlin"
    // ISO 8601 Format mit Zeitzonenoffset
    return now.toLocaleString('sv-SE', { timeZone: 'Europe/Berlin', hour12: false }).replace(' ', 'T') + formatTimezoneOffset();
}

/**
 * Formatiert den Zeitzonenoffset im Format "+HH:MM" oder "-HH:MM".
 * @returns {string} - Der formattierte Zeitzonenoffset.
 */
function formatTimezoneOffset() {
    const offset = new Date().getTimezoneOffset();
    const absOffset = Math.abs(offset);
    const hours = String(Math.floor(absOffset / 60)).padStart(2, '0');
    const minutes = String(absOffset % 60).padStart(2, '0');
    return (offset <= 0 ? '+' : '-') + hours + ':' + minutes;
}
