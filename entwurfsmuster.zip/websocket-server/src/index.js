const WebSocket = require('ws');
const readline = require('readline');

// Konfigurierbare Spielfeldgröße
const FIELD_WIDTH = 25;
const FIELD_HEIGHT = 25;

// Port, auf dem der Server lauscht
const PORT = 8080;

// Maximale Anzahl gespeicherter Befehle
const MAX_COMMANDS = 100000;

// Array zum Speichern der letzten Befehle
const commandHistory = [];

// Erstellen eines neuen WebSocket-Servers
const wss = new WebSocket.Server({port: PORT}, () => {
    console.log(`WebSocket-Server läuft auf ws://localhost:${PORT}`);
});

// Map zur Zuordnung von WebSocket-Verbindungen zu playerIds
const wsPlayerMap = new Map();

// Spielzustand
const gameState = {
    players: new Map(), // playerId -> { position: { x, y }, type: 'Kobold' | 'Krümelmonster' | 'Geist' }
    items: [], // { type: 'Hexenmaske' | 'Clownsnase' | 'Frankensteinschraube', position: { x, y } }
    maxItems: {
        Hexenmaske: 20,
        Clownsnase: 20,
        Frankensteinschraube: 3
    }
};

// Erlaubte Spielertypen
const ALLOWED_PLAYER_TYPES = ['Kobold', 'Krümelmonster', 'Drache', 'Geist'];

// Verbindung bei jedem neuen Client
wss.on('connection', (ws) => {
    console.log('Neuer Client verbunden');

    // Senden der letzten x Befehle an den neuen Client
    commandHistory.slice(-100).forEach((command) => {
        ws.send(JSON.stringify(command));
    });

    // Empfang von Nachrichten vom Client
    ws.on('message', (message) => {
        console.log(`Empfangene Nachricht: ${message}`);

        let command;
        try {
            command = JSON.parse(message);
        } catch (e) {
            console.error('Ungültiges JSON:', e);
            ws.send(JSON.stringify({error: 'Ungültiges JSON-Format'}));
            return;
        }

        // Validierung des Befehls
        if (validateCommand(command)) {
            const {playerId, type, payload, position} = command;

            // Mappe die WebSocket-Verbindung auf die playerId
            wsPlayerMap.set(ws, playerId);

            // Initialisiere Spieler, falls nicht vorhanden und nicht ein 'player_left' Befehl
            if (!gameState.players.has(playerId) && type !== 'player_left') {
                if (type === 'player_joined') {
                    // Handhabung des 'player_joined' Befehls
                    handlePlayerJoined(ws, command);
                } else {
                    // Für andere Befehle initialisieren wir den Spieler nur mit Position
                    gameState.players.set(playerId, {position: position || {x: 0, y: 0}, type: 'geist'}); // Standardtyp 'geist'
                    console.log(`Neuer Spieler hinzugefügt: ${playerId} mit Startposition (${gameState.players.get(playerId).position.x}, ${gameState.players.get(playerId).position.y})`);
                }
            }

            switch (type) {
                case 'move':
                    handleMoveCommand(command);
                    break;

                case 'action':
                    handleActionCommand(command);
                    break;

                case 'player_joined':
                    // Bereits in der Initialisierung behandelt
                    break;

                case 'player_left':
                    handlePlayerLeft(playerId);
                    break;

                default:
                    console.warn(`Unbekannter Befehlstyp empfangen: ${type}`);
                    ws.send(JSON.stringify({error: `Unbekannter Befehlstyp: ${type}`}));
            }
        } else {
            console.warn('Ungültige Befehlsstruktur empfangen:', command);
            ws.send(JSON.stringify({error: 'Ungültige Befehlsstruktur'}));
        }
    });

    // Verbindung schließen
    ws.on('close', () => {
        console.log('Client getrennt');
        const playerId = wsPlayerMap.get(ws);
        if (playerId) {
            wsPlayerMap.delete(ws);
            gameState.players.delete(playerId); // Spieler aus dem Spiel entfernen
            console.log(`Spieler aus dem Spiel entfernt: ${playerId}`);

            const playerLeftCommand = {
                type: 'player_left',
                playerId: playerId,
                timestamp: getCurrentTimestamp()
            };

            addToCommandHistory(playerLeftCommand);
            broadcast(JSON.stringify(playerLeftCommand));
            console.log(`'player_left' Ereignis für Spieler ${playerId} gesendet`);
        }
    });

    // Fehlerbehandlung
    ws.on('error', (error) => {
        console.error(`WebSocket-Fehler: ${error}`);
    });
});

/**
 * Validiert die Struktur des empfangenen Spielbefehls.
 * Erlaubt beliebige 'type' Werte, solange 'playerId' vorhanden ist.
 * @param {Object} command - Der Spielbefehl.
 * @returns {boolean} - Gibt true zurück, wenn der Befehl gültig ist.
 */
function validateCommand(command) {
    if (typeof command !== 'object' || command === null) {
        return false;
    }

    if (typeof command.playerId !== 'string' || command.playerId.trim() === '') {
        return false;
    }

    if (typeof command.type !== 'string' || command.type.trim() === '') {
        return false;
    }

    // Weitere spezifische Validierungen können hier hinzugefügt werden

    return true;
}

/**
 * Handhabt den 'player_joined' Befehl.
 * @param {WebSocket} ws - Die WebSocket-Verbindung des Clients.
 * @param {Object} command - Der empfangene Befehl.
 */
function handlePlayerJoined(ws, command) {
    const {playerId, position, payload} = command;
    const type = payload && typeof payload.type === 'string' ? payload.type : 'Kobold';
    // Validierung des Spielertyps
    if (typeof type !== 'string' || !ALLOWED_PLAYER_TYPES.includes(type)) {
        console.warn(`Ungültiger Spielertyp von Spieler ${playerId}: ${type}`);
        ws.send(JSON.stringify({error: `Ungültiger Spielertyp: ${type}`}));
        return;
    }

    if (!position || typeof position.x !== 'number' || typeof position.y !== 'number') {
        console.warn(`Player_joined-Befehl ohne gültige Position empfangen von Spieler ${playerId}`);
        ws.send(JSON.stringify({error: 'Player_joined-Befehl erfordert eine gültige Position'}));
        return;
    }

    // Spieler mit Position und Typ hinzufügen
    gameState.players.set(playerId, {position: position, type: type, items: []});
    console.log(`Spieler beigetreten: ${playerId} (${type}) bei Position (${position.x}, ${position.y})`);
    addToCommandHistory(command);
    broadcast(JSON.stringify(command));
}

/**
 * Handhabt den 'move' Befehl.
 * @param {Object} command - Der empfangene Befehl.
 */
function handleMoveCommand(command) {
    const {playerId, payload, position} = command;

    if (payload && typeof payload.direction === 'string') {
        const {direction} = payload;
        const player = gameState.players.get(playerId);
        if (player) {
            const oldPosition = {...player.position};
            switch (direction.toLowerCase()) {
                case 'up':
                    player.position.y = Math.max(0, player.position.y - 1);
                    break;
                case 'down':
                    player.position.y = Math.min(FIELD_HEIGHT - 1, player.position.y + 1);
                    break;
                case 'left':
                    player.position.x = Math.max(0, player.position.x - 1);
                    break;
                case 'right':
                    player.position.x = Math.min(FIELD_WIDTH - 1, player.position.x + 1);
                    break;
                default:
                    console.warn(`Unbekannte Bewegungsrichtung von Spieler ${playerId}: ${direction}`);
                    break;
            }
            console.log(`Spieler ${playerId} bewegt von (${oldPosition.x}, ${oldPosition.y}) zu (${player.position.x}, ${player.position.y})`);

            // Speichern des Bewegungsbefehls in der Historie
            addToCommandHistory(command);

            // Broadcast des Befehls an alle verbundenen Clients
            broadcast(JSON.stringify(command));

            // Überprüfe Kommunikation
            checkCommunicate(playerId);

            // Überprüfe und handle Gegenstandserfassung
            checkItemPickup(playerId);
        }
    } else {
        console.warn(`Move-Befehl ohne gültige Richtung empfangen von Spieler ${playerId}`);
        const ws = getWebSocketByPlayerId(playerId);
        if (ws) {
            ws.send(JSON.stringify({error: 'Move-Befehl erfordert eine gültige Richtung im Payload'}));
        }
    }
}

/**
 * Handhabt den 'action' Befehl.
 * @param {Object} command - Der empfangene Befehl.
 */
function handleActionCommand(command) {
    const {playerId, payload} = command;

    if (payload && typeof payload.action === 'string') {
        console.log(`Aktion von Spieler ${playerId}: ${payload.action}`);
        // Hier können Sie Aktionen weiterverarbeiten
        addToCommandHistory(command);
        broadcast(JSON.stringify(command));
    } else {
        console.warn(`Action-Befehl ohne gültige Aktion empfangen von Spieler ${playerId}`);
        const ws = getWebSocketByPlayerId(playerId);
        if (ws) {
            ws.send(JSON.stringify({error: 'Action-Befehl erfordert eine gültige Aktion im Payload'}));
        }
    }
}

/**
 * Holt die WebSocket-Verbindung anhand der playerId.
 * @param {string} playerId
 * @returns {WebSocket|null}
 */
function getWebSocketByPlayerId(playerId) {
    for (const [ws, id] of wsPlayerMap.entries()) {
        if (id === playerId) {
            return ws;
        }
    }
    return null;
}

/**
 * Fügt einen Befehl zur Historie hinzu und stellt sicher, dass die maximale Anzahl nicht überschritten wird.
 * @param {Object} command - Der Spielbefehl.
 */
function addToCommandHistory(command) {
    commandHistory.push(command);
    if (commandHistory.length > MAX_COMMANDS) {
        commandHistory.shift(); // Entfernt den ältesten Befehl
    }
}

/**
 * Sendet eine Nachricht an alle verbundenen Clients.
 * @param {string} data - Die zu sendende Nachricht.
 */
function broadcast(data) {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(data);
        }
    });
}

/**
 * Gibt den aktuellen Timestamp in ISO 8601 Format zurück, angepasst an die deutsche Zeitzone.
 * @returns {string} - Der formatierte Timestamp.
 */
function getCurrentTimestamp() {
    const now = new Date();
    // Deutschland befindet sich in der Zeitzone "Europe/Berlin"
    // ISO 8601 Format mit Zeitzonenoffset
    return now.toLocaleString('sv-SE', {
        timeZone: 'Europe/Berlin',
        hour12: false
    }).replace(' ', 'T') + formatTimezoneOffset();
}

/**
 * Formatiert den Zeitzonenoffset im Format "+HH:MM" oder "-HH:MM".
 * @returns {string} - Der formatierte Zeitzonenoffset.
 */
function formatTimezoneOffset() {
    const offset = new Date().getTimezoneOffset();
    const absOffset = Math.abs(offset);
    const hours = String(Math.floor(absOffset / 60)).padStart(2, '0');
    const minutes = String(absOffset % 60).padStart(2, '0');
    return (offset <= 0 ? '+' : '-') + hours + ':' + minutes;
}

/**
 * Holt den aktuellen Spielzustand, um ihn im 'darstellen' Ereignis zu senden.
 * @returns {Object}
 */
function getGameState() {
    return {
        players: Array.from(gameState.players.entries()).map(([playerId, data]) => ({
            playerId,
            position: data.position,
            type: data.type,
            items: data.items
        })),
        items: gameState.items
    };
}

/**
 * Broadcastet das 'darstellen' Ereignis alle 10 Sekunden an alle Clients.
 */
setInterval(() => {
    const darstellenEvent = {
        type: 'darstellen',
        timestamp: getCurrentTimestamp(),
        state: getGameState()
    };
    console.log(`'darstellen' Ereignis gesendet: ${JSON.stringify(darstellenEvent)}`);
    broadcast(JSON.stringify(darstellenEvent));
}, 10000);

/**
 * Erzeugt zufällig Gegenstände auf dem Spielfeld alle 5-20 Sekunden.
 */
function scheduleItemCreation() {
    const interval = getRandomInt(5000, 20000); // 5-20 Sekunden
    console.log(`Nächste Gegenstandserzeugung in ${interval / 1000} Sekunden`);
    setTimeout(() => {
        createRandomItem();
        scheduleItemCreation(); // Nächste Erstellung planen
    }, interval);
}

/**
 * Startet die Gegenstandserzeugung beim Serverstart.
 */
scheduleItemCreation();
var cnt = 0
while (cnt < 0) {
    createRandomItem();
    cnt++;
}

/**
 * Erzeugt einen zufälligen Gegenstand auf dem Spielfeld, wenn die maximale Anzahl nicht überschritten ist.
 */
function createRandomItem() {
    const itemTypes = ['Hexenmaske', 'Clownsnase', "Frankensteinschraube"];
    // Zufällige Auswahl eines Gegenstandstyps basierend auf verbleibender Kapazität
    const availableTypes = itemTypes.filter(type => {
        const currentCount = gameState.items.filter(item => item.type === type).length;
        return currentCount < gameState.maxItems[type];
    });

    if (availableTypes.length === 0) {
        // Keine verfügbaren Gegenstandstypen mehr
        console.log('Keine verfügbaren Gegenstandstypen mehr zur Erstellung');
        return;
    }

    const itemType = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    const position = getRandomPosition();

    const newItem = {
        type: itemType,
        position: position
    };
    gameState.items.push(newItem);

    console.log(`Gegenstand erstellt: ${itemType} an Position (${position.x}, ${position.y})`);

    const itemCreatedEvent = {
        type: 'item_created',
        item: newItem,
        timestamp: getCurrentTimestamp()
    };
    addToCommandHistory(itemCreatedEvent);
    broadcast(JSON.stringify(itemCreatedEvent));
    console.log(`'item_created' Ereignis gesendet: ${JSON.stringify(itemCreatedEvent)}`);
}

/**
 * Gibt eine zufällige Position innerhalb des Spielfelds zurück.
 * @returns {Object} - { x: Number, y: Number }
 */
function getRandomPosition() {
    return {
        x: getRandomInt(0, FIELD_WIDTH - 1),
        y: getRandomInt(0, FIELD_HEIGHT - 1)
    };
}

/**
 * Gibt eine zufällige ganze Zahl zwischen min und max zurück (inklusive).
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Überprüft, ob zwei oder mehr Spieler auf dem gleichen Feld sind und sendet ein 'kommunizieren' Ereignis.
 * @param {string} playerId - Die ID des Spielers, der sich bewegt hat.
 */
function checkCommunicate(playerId) {
    const movingPlayer = gameState.players.get(playerId);
    if (!movingPlayer) return;

    const overlappingPlayers = Array.from(gameState.players.entries())
        .filter(([id, data]) => id !== playerId && data.position.x === movingPlayer.position.x && data.position.y === movingPlayer.position.y)
        .map(([id, _]) => id);

    if (overlappingPlayers.length > 0) {
        const communicateEvent = {
            type: 'kommunizieren',
            players: [playerId, ...overlappingPlayers],
            position: movingPlayer.position,
            timestamp: getCurrentTimestamp()
        };
        broadcast(JSON.stringify(communicateEvent));
        console.log(`'kommunizieren' Ereignis gesendet für Spieler ${playerId} und Spieler ${overlappingPlayers.join(', ')} an Position (${movingPlayer.position.x}, ${movingPlayer.position.y})`);
    }
}

/**
 * Überprüft, ob ein Spieler auf einem Feld mit einem Gegenstand steht und entfernt den Gegenstand.
 * Sendet ein 'item_picked' Ereignis.
 * @param {string} playerId
 */
function checkItemPickup(playerId) {
    const player = gameState.players.get(playerId);
    if (!player) return;

    const itemIndex = gameState.items.findIndex(item => item.position.x === player.position.x && item.position.y === player.position.y);

    if (itemIndex !== -1) {
        const pickedItem = gameState.items.splice(itemIndex, 1)[0];
        console.log(`Spieler ${playerId} hat Gegenstand aufgenommen: ${pickedItem.type} an Position (${pickedItem.position.x}, ${pickedItem.position.y})`);
        player.items.push(pickedItem);
        const itemPickedEvent = {
            type: 'item_picked',
            playerId: playerId,
            item: pickedItem,
            timestamp: getCurrentTimestamp()
        };
        addToCommandHistory(itemPickedEvent);
        broadcast(JSON.stringify(itemPickedEvent));
        console.log(`'item_picked' Ereignis gesendet: ${JSON.stringify(itemPickedEvent)}`);
    }
}

/**
 * Handhabt das Verlassen eines Spielers.
 * @param {string} playerId
 */
function handlePlayerLeft(playerId) {
    if (gameState.players.has(playerId)) {
        gameState.players.delete(playerId);
        console.log(`Spieler aus dem Spiel entfernt: ${playerId}`);

        const playerLeftCommand = {
            type: 'player_left',
            playerId: playerId,
            timestamp: getCurrentTimestamp()
        };
        addToCommandHistory(playerLeftCommand);
        broadcast(JSON.stringify(playerLeftCommand));
        console.log(`'player_left' Ereignis für Spieler ${playerId} gesendet`);
    }
}


// console reader
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.emitKeypressEvents(process.stdin);
if (process.stdin.isTTY) {
    process.stdin.setRawMode(true);
}

console.log("Drücke 'g', um 5 neue Gegenstände zu erzeugen. Drücke 'q' zum Beenden.");

process.stdin.on('keypress', (str, key) => {
    if (key.sequence === 'g' || key.sequence === 'G') {
        console.log("Taste 'g' gedrückt. Erzeuge 5 neue Gegenstände...");
        for (let i = 0; i < 5; i++) {
            createRandomItem();
        }
    } else if (key.sequence === 'q' || (key.ctrl && key.name === 'c')) {
        console.log("Beende den Server...");
        process.exit();
    }
});
